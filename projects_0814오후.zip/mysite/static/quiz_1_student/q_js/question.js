

//Array of Objects
const quiz = [
    {
        q: 'Artificial intelligence is what humans imitate artificial intelligence?',
        options: ['true', 'false'],  
        answer:0,
        aifactor:'aei'
    },
    {
        q: 'What is TM stands for?',
        options: ['Teachable Machine', 'Teacher Machine'], 
        answer:0,
        aifactor:'aei'
    },
    {
        q: 'Choose all the ways to enter data in Teachable Machine',
        options: ['Upload', 'WebCam', 'Upload', 'WebCam', 'No answer'], 
        answer:2,
        aifactor:'aei'
    },
    {
        q: 'We are going to create a "fruit sorter" using the following data. How many classes are required?',
        options: ['1 class', '3 classes', '6 Classes'], 
        answer:1,
        img: 'q_img/fruit.png',
        aifactor:'oci'
    },
    {
        q: 'For classify using information on human joints such as head, neck, and shoulders. What type of data will be use? ',
        options: ['image data', 'sound data', 'pose data'], 
        answer:2,
        aifactor:'rop'
    },
    {
        q: 'What is not the process of learning through TM?',
        options: ['input data', 'class classification', 'Training', 'deploy'],
        answer:3,
        aifactor:'oci'
    },
    {
        q: 'When training images, what is incorrectly labeled or not properly classified because of poor learning?',
        options: ['data bias', 'data collision'],
        answer: 0,
        aifactor:'rop'
    }
]