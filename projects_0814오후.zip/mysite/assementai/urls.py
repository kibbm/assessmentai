from django.urls import path
from . import views

app_name = 'assementai'

urlpatterns = [
    path('', views.index, name='index'), # 이렇게 하니, 로그인하고 assementai의 list.html로 이동한다!^^
    path('<int:evaresult_id>', views.detail, name='detail'),

    #history
    path('history/<int:evaresult_id>', views.history, name='history'),
]