from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.template import context #추가

from .models import EvaResult

# Create your views here.
def index(request):
    '''      #but, 쿼리 수정해야 함~~~ classid=3-14인걸로!

    assementai 목록 출력
    '''
    evaresult_list = EvaResult.objects.order_by()#작성일자 바꾸지 않음.
    #evaresult_list = EvaResult.objects.order_by('-create_date')#역순
    context = {'evaresult_list': evaresult_list}
    return render(request, 'assementai/evaresult_list.html', context)


def detail(request, evaresult_id):
    '''
    assementai 내용 출력
    '''
    print("views.py의 detail함수를 시작~~==")
    evaresult = EvaResult.objects.get(id=evaresult_id)
    context = {'evaresult': evaresult}
    return render(request, 'assementai/evaresult_detail.html', context)


def history(request, evaresult_id):
    '''
    assementai 내용 출력
    '''
    print("views.py의 detail함수를 시작~~==")
    evaresult = EvaResult.objects.get(id=evaresult_id)
    context = {'evaresult': evaresult}
    return render(request, 'assementai/evaresult_history.html', context)