from django.apps import AppConfig


class AssementaiConfig(AppConfig):
    name = 'assementai'
