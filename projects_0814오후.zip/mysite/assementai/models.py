from django.db import models

# Create your models here.


class EvaResult(models.Model):
    stuid = models.CharField(max_length=100)  # 학생id

    subjectid = models.CharField(max_length=100)         #과목 id
    classid = models.CharField(max_length=100)           #클래스 id
    round = models.CharField(max_length=100)  # 회차

    q1 = models.CharField(max_length=100)                # 1번 문항 점수(맞으면 1, 틀리면 0)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)

    aifactor1 = models.CharField(max_length=100)        # aifactor 1~7문항.('aei', 'oci', 'rop' 중 1개)
    aifactor2 = models.CharField(max_length=100)
    aifactor3 = models.CharField(max_length=100)
    aifactor4 = models.CharField(max_length=100)
    aifactor5 = models.CharField(max_length=100)
    aifactor6 = models.CharField(max_length=100)
    aifactor7 = models.CharField(max_length=100)

    create_date = models.DateTimeField()

    def __str__(self):
        return self.stuid





