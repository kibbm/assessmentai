from django.contrib import admin
from .models import EvaResult


# Register your models here.
class EvaResultAdmin(admin.ModelAdmin):
    search_fields = ['stuid']

admin.site.register(EvaResult, EvaResultAdmin)

