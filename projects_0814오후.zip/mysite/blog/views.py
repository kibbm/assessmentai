from django.shortcuts import render
from .models import Bpost

# Create your views here.
def index(request):
    posts = Bpost.objects.all().order_by('-pk')

    return render(
        request,
        'blog/blog_list.html',
        {
        'posts':posts,
        }
    )
