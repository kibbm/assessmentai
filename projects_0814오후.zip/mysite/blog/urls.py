from django.urls import path
from . import views

app_name = 'blog'

urlpatterns = [
    path('', views.index, name='index'), # 별명 안 지어주니 못 찾아간다..ㅠ 이 부분 채울겁니다~
]